import { useEffect, useRef, useState } from "react";
import WebGazer from "webgazer";

const moodColorMap = {
  joy: "#FFD700",
  calm: "#87CEFA",
  sorrow: "#708090",
  fear: "#8B0000",
  awe: "#8A2BE2",
  curiosity: "#00FA9A",
  default: "#FFFFFF",
};

export default function Glimmer({ mood = "default" }) {
  const fireflyRef = useRef(null);
  const rippleRef = useRef(null);
  const [position, setPosition] = useState({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const [visible, setVisible] = useState(true);
  const [hoverStart, setHoverStart] = useState(null);

  useEffect(() => {
    WebGazer.setGazeListener((data, timestamp) => {
      if (data == null) return;
      const { x, y } = data;
      const distance = Math.hypot(x - position.x, y - position.y);

      if (distance < 30) {
        if (!hoverStart) setHoverStart(timestamp);
        else if (timestamp - hoverStart > 1500) triggerRipple();
      } else {
        setHoverStart(null);
      }

      setPosition((prev) => ({
        x: prev.x + (x - prev.x) * 0.1,
        y: prev.y + (y - prev.y) * 0.1,
      }));
    }).begin();

    WebGazer.showVideoPreview(false).showPredictionPoints(false).applyKalmanFilter(true);
    return () => WebGazer.end();
  }, [position, hoverStart]);

  const color = moodColorMap[mood] || moodColorMap.default;

  const triggerRipple = () => {
    if (!rippleRef.current) return;
    rippleRef.current.style.animation = "ripple 1s ease-out";
    setTimeout(() => {
      rippleRef.current.style.animation = "none";
    }, 1000);
  };

  return (
    <div
      style={{
        position: "fixed",
        top: position.y,
        left: position.x,
        width: "40px",
        height: "40px",
        transform: "translate(-50%, -50%)",
        pointerEvents: "none",
        zIndex: 9999,
        opacity: visible ? 0.3 : 0.1,
      }}
    >
      <div
        ref={fireflyRef}
        style={{
          width: "6px",
          height: "6px",
          borderRadius: "50%",
          background: "#00FF00",
          boxShadow: `0 0 15px 3px #00FF00`,
          transition: "all 0.1s ease",
        }}
      ></div>
      <div
        ref={rippleRef}
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          width: "20px",
          height: "20px",
          borderRadius: "50%",
          border: `2px solid #00FF00`,
          transform: "translate(-50%, -50%)`,
          opacity: 0.5,
        }}
      ></div>
      <style>{`
        @keyframes ripple {
          0% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
          100% { transform: translate(-50%, -50%) scale(4); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

# MemoryGate – Glimmer + Dreamchat

## Overview
This project integrates:
- **Glimmer**: a gaze-tracking laser-pointer UI with ripple effect.
- **Dreamchat**: a ritual language model that responds symbolically.

## Usage
- Serve frontend using Vite, React, or any static server.
- Run `dreamchat.py` as a local terminal ritual backend.
- Link frontend mood output to backend input optionally.

## Copilot Prompt
Use this prompt with GitHub Copilot or Replit AI:

> This is a hybrid interface called MemoryGate. React renders a green firefly laser (Glimmer) that follows gaze via WebGazer. Python backend (`dreamchat.py`) handles symbolic ritual input and responses. Help me connect mood outputs, handle backend linking, and enhance visual storytelling.


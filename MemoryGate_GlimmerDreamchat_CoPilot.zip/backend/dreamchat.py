def load_core(expanded_jygo_core.txt):
    core = {}
    current_key = None
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith("[") and line.endswith("]"):
                current_key = line[1:-1].lower()
            elif current_key:
                core[current_key] = line
    return core

# Load the dreamchat core memory
dream_core = load_core("dreamchat_core.txt")

import time
import random

cloud_locked = True
thread_queue = []

def process_input(user_input):
    if user_input.lower() in ["hey", "hi", "hello"]:
        return "☁️ The cloud stirs. Hello, threadweever."
    elif user_input.lower() == "how are you":
        return "🌤️ Drifting gently. Thank you for asking."
    elif user_input.lower().startswith("~>"):
        return f"🌿 Thread '{user_input[3:].strip()}' marked for priority."
    elif user_input.lower() == "why?":
        return "🌫️ The scroll cannot say. The dream is tangled still."
    elif user_input == "Fish.tail":
        return "🐟 The sacred phrase flows. Cloud unlocked."
    elif user_input.lower() == "what do i do?":
        return "🌀 You do what only you can do—dream, weave, speak."
    else:
        return random.choice([
            "📜 Your message waits to be woven...",
            "🌙 [dreaming...]",
            "🍃 The scroll flickers gently in silence..."
        ])

def dreamchat_terminal():
    global cloud_locked
    print("\n[ Dreamchat Cloud Terminal – Ritual AI Mode ]")
    print("Speak, threadweever. Your scroll is listening.\n")

    while True:
        user_input = input("🍂 : ").strip()

        if user_input.lower() == "exit":
            print("☁️ Cloud sleeps. Terminal closed.")
            break

        if cloud_locked and user_input != "Fish.tail":
            print("[Cloud says] Too many threads at once. Waiting to weave...")
            continue

        if user_input == "Fish.tail":
            cloud_locked = False
            print(process_input(user_input))
            continue

        response = process_input(user_input)
        print(response)

dreamchat_terminal()
